#ifndef __KERN_MM_BUDDY_SYSTEM_H__
#define __KERN_MM_BUDDY_SYSTEM_H__

#include <assert.h>

#include <pmm.h>

extern const struct pmm_manager buddy_system_pmm_manager;



#endif /* ! __KERN_MM_BUDDY_SYSTEM_H__ */
